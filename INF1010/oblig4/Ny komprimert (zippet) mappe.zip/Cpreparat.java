public class Cpreparat extends Legemiddel{
	public Cpreparat(String _navn, double _pris, double _virkestoffMg){
		super(_navn, _pris, _virkestoffMg);
	}
}