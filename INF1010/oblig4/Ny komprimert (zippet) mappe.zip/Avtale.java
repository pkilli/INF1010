public interface Avtale{
	public int avtaleNummer();
}