public interface Lik{
	public boolean samme(String _verdi);
}