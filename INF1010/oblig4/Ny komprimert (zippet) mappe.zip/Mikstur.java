public interface Mikstur{
	public double hentStorrelseCm3();
	public double hentVirkestoffCm3();
}