public class Lege implements Lik, Avtale{
	private String navn;
	private int avtalenummer;
	public Lege(String _navn){
		navn = _navn;
	}
	
	public boolean samme(String _verdi){
		boolean ret = false;
		if(navn != null){
			if(navn.equals(_verdi))
					ret = true;
			}	
		return ret;
	}
	public int avtaleNummer(){
		if(String.valueOf(avtalenummer) != null)
			return avtalenummer;
		return -1;
	}
	public String toString(){return navn;}
}
