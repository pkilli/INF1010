public interface Pille{
	public int hentAntallPiller();
	public double hentVirkestoffPerPille();
}